import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private http:HttpClient) { }





public addPackage(place){
  return this.http.post("http://localhost:9090/packages/post",place,{responseType:'text' as 'json'});

}

public getPackage(){
  return this.http.get("http://localhost:9090/packages/get");
}

public deletePackage(id){
  return this.http.delete("http://localhost:9090/packages/remove/"+id);
}

public getUsers(){
  return this.http.get("http://localhost:9090/user/get");
}
public editPackage(id,place){
  return this.http.put("http://localhost:9090/packages/edit/"+id, place);
}
public getPackageById(id){
  return this.http.get("http://localhost:9090/packages/get/"+id);
}

getData(packages)
  {
    
    return  this.http.get("http://localhost:9090/packages/findByPlace/"+ "filterData",packages);
  }


  // uploadImage(){
  //    return this.http.post("");
  // }
}
