import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { ActivatedRoute, Router } from '@angular/router';
import { PackageDetails } from '../shared/booking_details';

@Component({
  selector: 'app-edit-package',
  templateUrl: './edit-package.component.html',
  styleUrls: ['./edit-package.component.css']
})
export class EditPackageComponent implements OnInit {
  packages:PackageDetails=new PackageDetails(0,"",0,0,"",0,0,0,0,0,0,0,0,null);
 
  // packages:any;
  message:any;
  
  constructor(private service:AdminService, private router:Router, private route:ActivatedRoute) { }

  ngOnInit() {
    let id=this.route.snapshot.paramMap.get('id');
    let resp=this.service.getPackageById(id);
    resp.subscribe((data)=>this.packages=data);
    
  }
  public addPackage(){
    let id=this.route.snapshot.paramMap.get('id');
 let response=this.service.editPackage(id,this.packages);
 response.subscribe(data=>this.message=data);
 this.router.navigateByUrl('/Packages');
  }

// public editPackage(){
    
//  let response=this.service.editPackage(this.place);
//  response.subscribe(data=>this.message=data);
//  this.router.navigateByUrl('/Packages');
//   }
}
