import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule} from '@angular/forms'
import { AppComponent } from './app.component';
import { BasicMenuComponent } from './basic-menu/basic-menu.component';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { AdminMenuComponent } from './admin-menu/admin-menu.component';
import { PackageDetailsComponent } from './package-details/package-details.component';
import { AppRoutingModule } from './app-routing.module';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { FooterComponent } from './footer/footer.component';
import { ViewPackageComponent } from './view-package/view-package.component';
import { ViewUserComponent } from './view-user/view-user.component';
import { ViewBookingComponent } from './view-booking/view-booking.component';
import { HttpClientModule } from '@angular/common/http';
import { AdminService } from './admin.service';
import { EditPackageComponent } from './edit-package/edit-package.component';
import { ViewPackageIdComponent } from './view-package-id/view-package-id.component';
import { UserViewPackageComponent } from './user-view-package/user-view-package.component';
import { AdminLogoutComponent } from './admin-logout/admin-logout.component';
import { SearchComponent } from './search/search.component';
import { ImageuploadComponent } from './imageupload/imageupload.component';

@NgModule({
  declarations: [
    AppComponent,
    BasicMenuComponent,
    LoginComponent,
    AdminComponent,
    AdminMenuComponent,
    PackageDetailsComponent,
    AdminLoginComponent,
    AboutUsComponent,
    ContactUsComponent,
    FooterComponent,
    ViewPackageComponent,
    ViewUserComponent,
    ViewBookingComponent,
    EditPackageComponent,
    ViewPackageIdComponent,
    UserViewPackageComponent,
    AdminLogoutComponent,
    SearchComponent,
    ImageuploadComponent, 
    
   
  ],
  
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [AdminService],
  bootstrap: [AppComponent]
})
export class AppModule { }
