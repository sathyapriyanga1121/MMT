import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPackageIdComponent } from './view-package-id.component';

describe('ViewPackageIdComponent', () => {
  let component: ViewPackageIdComponent;
  let fixture: ComponentFixture<ViewPackageIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewPackageIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPackageIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
