import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-view-package-id',
  templateUrl: './view-package-id.component.html',
  styleUrls: ['./view-package-id.component.css']
})
export class ViewPackageIdComponent implements OnInit {

  packages:any;
  constructor(private service:AdminService, private router:Router, private route:ActivatedRoute) { }
total:number;

  ngOnInit() {
    var today = new Date().toISOString().split('T')[0];
    document.getElementsByName("txtDate")[0].setAttribute('min', today);

    let id=this.route.snapshot.paramMap.get('id');
    let resp=this.service.getPackageById(id);
    resp.subscribe((data)=>this.packages=data);
  }

  addBooking(){
    alert("Your Booking is confirmed!");
  }
  calculateSum(num1:number,num2:number,num3:number){
    this.total=num1+num2+num3;
    console.log(this.total);
  }
}
