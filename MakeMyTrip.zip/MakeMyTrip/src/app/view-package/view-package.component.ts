import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-view-package',
  templateUrl: './view-package.component.html',
  styleUrls: ['./view-package.component.css']
})
export class ViewPackageComponent implements OnInit {
  packages:any;

  constructor(private service:AdminService) { }

  
  public myFunction(id:number) {
    
    var confirmation = confirm("Are you sure you want to delete this package?");
    if (confirmation == true) {
     this.delete(id);
    }    
  }
  
  
public delete(id:number){
  let resp=this.service.deletePackage(id);
  resp.subscribe((data)=>this.packages=data);
}


  ngOnInit() {
    let resp=this.service.getPackage();
    resp.subscribe((data)=>this.packages=data);
  }

}
