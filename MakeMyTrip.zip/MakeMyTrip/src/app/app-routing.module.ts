import { NgModule } from '@angular/core';

import{RouterModule, Routes} from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminLogoutComponent } from './admin-logout/admin-logout.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { EditPackageComponent } from './edit-package/edit-package.component';
import { ImageuploadComponent } from './imageupload/imageupload.component';
import { LoginComponent } from './login/login.component';
import { PackageDetailsComponent } from './package-details/package-details.component';
import { AuthGaurdService } from './service/auth-gaurd.service';
import { UserViewPackageComponent } from './user-view-package/user-view-package.component';
import { ViewBookingComponent } from './view-booking/view-booking.component';
import { ViewPackageIdComponent } from './view-package-id/view-package-id.component';
import { ViewPackageComponent } from './view-package/view-package.component';
import { ViewUserComponent } from './view-user/view-user.component';

const routes:Routes=[
  { path: '' , redirectTo: '/Login', pathMatch: 'full' },
  {path:'AddPackage', component: PackageDetailsComponent,canActivate:[AuthGaurdService] },
  {path:'Login', component: LoginComponent},
  {path:'Admin', component:AdminLoginComponent},
  {path:'AboutUs', component: AboutUsComponent},
  {path:'ContactUs', component: ContactUsComponent},
  {path:'BookingDetails', component:ViewBookingComponent,canActivate:[AuthGaurdService] },
  {path:'Packages', component:ViewPackageComponent,canActivate:[AuthGaurdService] },
  {path:'UserDetails', component:ViewUserComponent,canActivate:[AuthGaurdService] },
  {path:'EditPackage/:id', component:EditPackageComponent,canActivate:[AuthGaurdService] },

  {path:'UserViewPackage', component:UserViewPackageComponent,canActivate:[AuthGaurdService] },
  {path:'ViewPackage/:id', component:ViewPackageIdComponent,canActivate:[AuthGaurdService] },

  {path:'ImageUpload', component:ImageuploadComponent},

  {path: 'logout', component: AdminLogoutComponent,canActivate:[AuthGaurdService]},
]

@NgModule({ 
  imports: [
    RouterModule.forRoot(routes) ],
  exports:
  [RouterModule]
})
export class AppRoutingModule { }
