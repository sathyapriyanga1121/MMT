export class User{
    constructor(
        userId:number,
        password:string,
        name:string,
        email:string,
        phone:number
    ){}

}