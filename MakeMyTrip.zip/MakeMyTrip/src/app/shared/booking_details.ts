
export class PackageDetails {
    constructor(
    id:number,
    place: string,
    noOfAdults:number,
    noOfChildren:number,
    description: string,
    stayAmount:number,
    foodAmount:number,
    busAmount:number,
    trainAmount:number,
    flightAmount:number,
    noOfDays:number,
    noOfNights:number,
    totalCost:number,
    image:File){}
} 
