import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserViewPackageComponent } from './user-view-package.component';

describe('UserViewPackageComponent', () => {
  let component: UserViewPackageComponent;
  let fixture: ComponentFixture<UserViewPackageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserViewPackageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserViewPackageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
