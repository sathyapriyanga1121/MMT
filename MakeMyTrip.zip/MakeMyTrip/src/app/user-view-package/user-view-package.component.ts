import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-user-view-package',
  templateUrl: './user-view-package.component.html',
  styleUrls: ['./user-view-package.component.css']
})
export class UserViewPackageComponent implements OnInit {
  packages:any;

  constructor(private service:AdminService) { }

  ngOnInit() {
    let resp=this.service.getPackage();
    resp.subscribe((data)=>this.packages=data);
  }

}
