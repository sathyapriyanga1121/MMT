import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-menu',
  templateUrl: './basic-menu.component.html',
  styleUrls: ['./basic-menu.component.css']
})
export class BasicMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
