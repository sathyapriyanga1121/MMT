import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AdminService } from '../admin.service';
import { PackageDetails } from '../shared/booking_details';

@Component({
  selector: 'app-package-details',
  templateUrl: './package-details.component.html',
  styleUrls: ['./package-details.component.css']
})
export class PackageDetailsComponent implements OnInit {

  place:PackageDetails=new PackageDetails(0,"",0,0,"",0,0,0,0,0,0,0,0,null);
  message:any;
  public image:any=File;
   
 

  constructor(private service:AdminService, private router:Router,private formBuilder:FormBuilder) { 
    
  }

  ngOnInit() {
  

  }

 

  onFileChanged(event) {
    const file = event.target.files[0];
    console.log(file);
    this.image=file;
  }

  public addPackage(){
    // const formData=new FormData();
    // formData.append('file',this.image);
  

 let response=this.service.addPackage(this.place);
 response.subscribe(data=>this.message=data);
 this.router.navigateByUrl('/Packages');

  }

}
