import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { HttpErrorResponse } from '@angular/common/http';
import { PackageDetails } from "../shared/booking_details";
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.css']
})
export class ViewBookingComponent implements OnInit {

    packages:any;           
  constructor(private service:AdminService,private router:Router) {
        
  }


  public popup(id:number) {
    var confirmation = confirm("Are you sure you want to delete this package?");
    if (confirmation == true) {
     this.delete(id);
    }    
  }

  
public delete(id:number){
  let resp=this.service.deletePackage(id);
  resp.subscribe((data)=>this.packages=data);
}

  ngOnInit(){
    let resp=this.service.getPackage();
     resp.subscribe((data)=>this.packages=data); 
}
}
