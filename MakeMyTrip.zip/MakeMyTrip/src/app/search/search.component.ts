import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AdminService } from '../admin.service';
import { PackageDetails } from '../shared/booking_details';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  packages:any;
  private data;
  constructor(private service:AdminService) { }

  ngOnInit() {
    this.getData(this.packages);
  }

  form = new FormGroup({
    place : new FormControl()
  });
  
  getData(packages)
  {
      this.service.getData(packages).subscribe(
        response => {
          // this.data = response.json();
        },
        error => {
          console.log("error while getting package Details");
        }
      );
  }

  searchForm(searchInfo)
  {
        this.packages.place = this.Place.value;
        
        this.getData(this.packages);
  }

  get Place()
  {
    return this.form.get('place');
  }
}
