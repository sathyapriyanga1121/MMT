package com.cg.mmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MakeMyTripApplicationTests {

	@Test
	void contextLoads() {
	}

}
