package com.cg.mmt.service;

import java.util.Optional;

import com.cg.mmt.beans.ImageModel;

public interface ImageService {
	 Optional<ImageModel> findByName(String name);
}
