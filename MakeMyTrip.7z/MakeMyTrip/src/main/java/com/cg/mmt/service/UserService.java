package com.cg.mmt.service;

import java.util.List;

import com.cg.mmt.beans.UserDetails;

public interface UserService {
	
	 public List<UserDetails> addUser(UserDetails users);
	 public List<UserDetails> viewUsers();
}
