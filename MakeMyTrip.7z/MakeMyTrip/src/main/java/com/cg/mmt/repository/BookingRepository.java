package com.cg.mmt.repository;

public interface BookingRepository  {

}
