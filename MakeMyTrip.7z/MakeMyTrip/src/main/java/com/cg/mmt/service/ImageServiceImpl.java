package com.cg.mmt.service;

import java.util.Optional;

import com.cg.mmt.beans.ImageModel;

public class ImageServiceImpl implements ImageService {

	@Override
	public Optional<ImageModel> findByName(String name) {
		
		return null;
	}

}
