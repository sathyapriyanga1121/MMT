package com.cg.mmt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.mmt.beans.Packages;

@Repository
public interface PackageRepository extends JpaRepository<Packages, Integer>{
	
	@Query(value = "select * from Package where place=?",nativeQuery=true)
    
    Packages findByPlace(String place) ;
	
}
