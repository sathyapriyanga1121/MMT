package com.cg.mmt.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mmt.beans.UserDetails;
import com.cg.mmt.service.UserService;


@SpringBootApplication
@RestController
@CrossOrigin(origins="*")
@RequestMapping("/user")
public class UserController {
	

	@Autowired
	private UserService userService;
	
	@PostMapping("/post")
	public String addUser(@RequestBody UserDetails users) {
		userService.addUser(users);
		return "user is created";		
	}
	
	@GetMapping("/get")
	public List<UserDetails> viewUsers() {
		return userService.viewUsers();	
	}
	

}
