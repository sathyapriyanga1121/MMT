package com.cg.mmt.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.sun.istack.NotNull;


@Entity
@Table(name="Package")
public class Packages {
	
   @Id
   @GeneratedValue
    private int id;
   @NotNull
    private String place;
   @NotNull
    private int noOfAdults;
   @NotNull
    private int noOfChildren;
   @NotNull
    private String description;
   @NotNull
    private int stayAmount;
   @NotNull
    private int foodAmount;
   @NotNull
    private int busAmount;
   @NotNull
    private int trainAmount;
   @NotNull
    private int flightAmount;
   @NotNull
    private int noOfDays;
   @NotNull
    private int noOfNights;
    @Lob
    private byte[] image;
    
    @NotNull
    private int totalCost=stayAmount+foodAmount+flightAmount;
    
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public int getNoOfAdults() {
		return noOfAdults;
	}
	public void setNoOfAdults(int noOfAdults) {
		this.noOfAdults = noOfAdults;
	}
	public int getNoOfChildren() {
		return noOfChildren;
	}
	public void setNoOfChildren(int noOfChildren) {
		this.noOfChildren = noOfChildren;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStayAmount() {
		return stayAmount;
	}
	public void setStayAmount(int stayAmount) {
		this.stayAmount = stayAmount;
	}
	public int getFoodAmount() {
		return foodAmount;
	}
	public void setFoodAmount(int foodAmount) {
		this.foodAmount = foodAmount;
	}
	public int getBusAmount() {
		return busAmount;
	}
	public void setBusAmount(int busAmount) {
		this.busAmount = busAmount;
	}
	public int getTrainAmount() {
		return trainAmount;
	}
	public void setTrainAmount(int trainAmount) {
		this.trainAmount = trainAmount;
	}
	public int getFlightAmount() {
		return flightAmount;
	}
	public void setFlightAmount(int flightAmount) {
		this.flightAmount = flightAmount;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public int getNoOfNights() {
		return noOfNights;
	}
	public void setNoOfNights(int noOfNights) {
		this.noOfNights = noOfNights;
	}

	public byte[] getImage() {
		return image;
	}
	public void setImage(byte[] image) {
		this.image = image;
	}
	
	public int getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}
	
	
	public Packages(int id, String place, int noOfAdults, int noOfChildren, String description, int stayAmount,
			int foodAmount, int busAmount, int trainAmount, int flightAmount, int noOfDays, int noOfNights,
			byte[] image, int totalCost) {
		super();
		this.id = id;
		this.place = place;
		this.noOfAdults = noOfAdults;
		this.noOfChildren = noOfChildren;
		this.description = description;
		this.stayAmount = stayAmount;
		this.foodAmount = foodAmount;
		this.busAmount = busAmount;
		this.trainAmount = trainAmount;
		this.flightAmount = flightAmount;
		this.noOfDays = noOfDays;
		this.noOfNights = noOfNights;
		this.image = image;
		this.totalCost = totalCost;
	}
	public Packages() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
    
    
	
	
}
