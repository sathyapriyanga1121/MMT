package com.cg.mmt.controllers;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/booking")
public class BookingController {
	
//	@Autowired
//	BookingRepository bookingRepo;
//	
//	
//	@PostMapping("/addBooking")
//	public String addBooking(@RequestBody List<BookingDetails> booking) {
//		bookingRepo.saveAll(booking);
//		return "Booking is done";
//	}
//	
//	@GetMapping("/viewBooking")
//	public List<BookingDetails> viewBooking(){
//		return bookingRepo.findAll();
//	}
//	
//	@DeleteMapping("/deletePackage/{id}")
//	public List<BookingDetails> deletePackageById(@PathVariable int id){
//	
//		bookingRepo.deleteById(id);
//		return bookingRepo.findAll();	
//	}
}
