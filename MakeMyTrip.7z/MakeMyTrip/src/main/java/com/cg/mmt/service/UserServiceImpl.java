package com.cg.mmt.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mmt.beans.UserDetails;
import com.cg.mmt.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	
	@Autowired
	private UserRepository userRepo;
	
	public List<UserDetails> addUser(UserDetails users){
		 userRepo.save(users);	
		 return userRepo.findAll();
	}
	
	public List<UserDetails> viewUsers(){
		return userRepo.findAll();
	}
}
