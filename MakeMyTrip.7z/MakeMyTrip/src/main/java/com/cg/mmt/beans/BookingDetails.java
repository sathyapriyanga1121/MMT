package com.cg.mmt.beans;


public class BookingDetails {
	
	private int userid;
	private String name;
	private long mobNo;
	private String email;
	private String place;
	private String modeOfTravelling;
	private int person;
	private int totalCost;
	private int stayCost;
	private int foodCost;
	private int travellingCost;
	private boolean paid;
	
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getModeOfTravelling() {
		return modeOfTravelling;
	}
	public void setModeOfTravelling(String modeOfTravelling) {
		this.modeOfTravelling = modeOfTravelling;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobNo() {
		return mobNo;
	}
	public void setMobNo(long mobNo) {
		this.mobNo = mobNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getPerson() {
		return person;
	}
	public void setPerson(int person) {
		this.person = person;
	}
	public int getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(int totalCost) {
		this.totalCost = totalCost;
	}
	public int getStayCost() {
		return stayCost;
	}
	public void setStayCost(int stayCost) {
		this.stayCost = stayCost;
	}
	public int getFoodCost() {
		return foodCost;
	}
	public void setFoodCost(int foodCost) {
		this.foodCost = foodCost;
	}
	public int getTravellingCost() {
		return travellingCost;
	}
	public void setTravellingCost(int travellingCost) {
		this.travellingCost = travellingCost;
	}
	public boolean isPaid() {
		return paid;
	}
	public void setPaid(boolean paid) {
		this.paid = paid;
	}
	
	
	
}
