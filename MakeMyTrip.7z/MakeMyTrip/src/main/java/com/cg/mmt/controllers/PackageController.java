package com.cg.mmt.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.mmt.beans.Packages;
import com.cg.mmt.repository.PackageRepository;
import com.cg.mmt.service.PackageService;

@SpringBootApplication
@RestController
@CrossOrigin(origins="*")
@RequestMapping("/packages")
public class PackageController {
	
	@Autowired
	private PackageRepository packageRepo;
	@Autowired
	private PackageService packageService;
	
	
	@PostMapping("/post")
	public String addPackage(@RequestBody Packages packages) {	
		List<Packages> packageList=packageService.addPackage(packages);
		if(packageList!=null) {
		return "Package has been added successfully";
		}
		else 
			return"Package cannot be added";
		
	}
	
	
	@GetMapping("/get")
	public List<Packages> viewPackage(){
		
		return packageService.viewPackage();
	}
	
	
	@GetMapping("/get/{id}")
	public Optional<Packages> viewPackageById(@PathVariable int id){

		return packageService.viewPackageById(id);
	}
	

	@DeleteMapping("/remove/{id}")
	public List<Packages> deletePackageById(@PathVariable int id){
		
		packageService.deletePackageById(id);
		return packageRepo.findAll();	
	}
	
	@PutMapping("/edit/{id}")
	 public String edit(@PathVariable int id, @RequestBody Packages packages) {
		
		packageService.edit(id, packages);
		return "Package editted";		
	    }
	
	
	@GetMapping("/findByPlace/{place}")   
	public Packages findByPlace(@PathVariable String place)
    {
    return packageRepo.findByPlace(place);
    }
	
//	@GetMapping("/viewAPackage")
//	public List<Packages> viewAPackage(@PathVariable String name){
//		return addPackageRepo.findOne(List<Packages> );
//	}

//	@RequestMapping(value="/packageId/{id}",method= RequestMethod.GET) 
//	public ResponseEntity<Packages> packageId(@PathVariable int id) 
//	{ 
//		Optional<Packages> pack=addPackageRepo.findById(id);	
//	    return new ResponseEntity<Packages>( HttpStatus.FOUND); 
//	    }
	
	}
