package com.cg.mmt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mmt.beans.Packages;
import com.cg.mmt.repository.PackageRepository;

@Service
public class PackageServiceImpl implements PackageService{
	
	@Autowired
	private PackageRepository packageRepo;
	
	
	@Override
	public List<Packages> addPackage(Packages packages) {
		int stay=packages.getStayAmount();
		int food=packages.getFoodAmount();
		int flight=packages.getFlightAmount();
		int total=stay+food+flight;
		packages.setTotalCost(total);
		
		packageRepo.save(packages);
		return packageRepo.findAll();
	}

	
	@Override
	public List<Packages> viewPackage() {
		return packageRepo.findAll();
	}

	@Override
	public Optional<Packages> viewPackageById(int id) {
		return packageRepo.findById(id);
	}
	
	public Packages findByPlace(String place) {
        
        return packageRepo.findByPlace(place);
	}
	
	@Override
	 public Packages edit(int id,Packages packages) {
	      packages.setId(id);
	      int stay=packages.getStayAmount();
			int food=packages.getFoodAmount();
			int flight=packages.getFlightAmount();
			int total=stay+food+flight;
			packages.setTotalCost(total);
			return packageRepo.save(packages);
	    }

	@Override
	public void deletePackageById(int id) {		
		 packageRepo.deleteById(id);
	}



	
}
