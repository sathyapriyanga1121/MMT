package com.cg.mmt.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cg.mmt.beans.Packages;
@Service
public interface PackageService {

	 List<Packages> addPackage(Packages packages);
	 List<Packages> viewPackage();
	 Optional<Packages> viewPackageById(int id);
	 void deletePackageById(int id);
	 Packages findByPlace(String name);
	 Packages edit(int id, Packages packages);
	
}
